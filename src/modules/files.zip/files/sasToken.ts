const { BlobServiceClient, generateBlobSASQueryParameters, StorageSharedKeyCredential } = require('@azure/storage-blob');

const account = '<your-storage-account-name>';
const accountKey = '<your-storage-account-key>';
const containerName = '<your-container-name>';
const blobName = '<your-blob-name>';

const sharedKeyCredential = new StorageSharedKeyCredential(account, accountKey);
const blobServiceClient = new BlobServiceClient(`https://${account}.blob.core.windows.net`, sharedKeyCredential);

const expiryDate = new Date();
expiryDate.setMinutes(expiryDate.getMinutes() + 30); // Set expiration time (e.g., 30 minutes from now)

const sasOptions = {
    containerName,
    blobName,
    expiresOn: expiryDate,
    permissions: 'r' // Read permission
};

const sasToken = generateBlobSASQueryParameters(sasOptions, sharedKeyCredential).toString();
const blobUrl = `https://${account}.blob.core.windows.net/${containerName}/${blobName}?${sasToken}`;

console.log(blobUrl); // Use this URL to access the blob with SAS
